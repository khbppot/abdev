"use client";

import { ArrowRight, Code, Zap } from "lucide-react";

export default function Hero() {
  const scrollToContact = () => {
    const element = document.querySelector('#contact');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section id="home" className="min-h-screen bg-[#0a0a0a] relative flex items-center justify-center px-6 py-20 overflow-hidden">
      {/* Background grid pattern */}
      <div className="absolute inset-0 opacity-10">
        <div 
          className="w-full h-full"
          style={{
            backgroundImage: `
              linear-gradient(rgba(0, 212, 255, 0.1) 1px, transparent 1px),
              linear-gradient(90deg, rgba(0, 212, 255, 0.1) 1px, transparent 1px)
            `,
            backgroundSize: '50px 50px'
          }}
        ></div>
      </div>

      {/* Floating tech elements */}
      <div className="absolute top-20 left-10 opacity-30">
        <Code size={32} className="text-[#00d4ff] animate-pulse" />
      </div>
      <div className="absolute top-40 right-20 opacity-30">
        <Zap size={28} className="text-[#00d4ff] animate-pulse delay-1000" />
      </div>
      <div className="absolute bottom-40 left-20 opacity-30">
        <div className="w-3 h-3 bg-[#00d4ff] rounded-full animate-ping"></div>
      </div>

      <div className="max-w-6xl mx-auto text-center relative z-10">
        {/* Main headline */}
        <div className="mb-8">
          <h1 
            className="text-5xl md:text-7xl lg:text-8xl font-bold text-white leading-tight mb-6"
            style={{ fontFamily: "JetBrains Mono, monospace" }}
          >
            <span className="block">Crafting the</span>
            <span className="block text-[#00d4ff]">Future of Tech</span>
          </h1>
          
          <p 
            className="text-xl md:text-2xl text-white/80 max-w-3xl mx-auto leading-relaxed"
            style={{ fontFamily: "Inter, sans-serif" }}
          >
            Full-stack developer and tech innovator building cutting-edge solutions
            that shape tomorrow's digital landscape.
          </p>
        </div>

        {/* CTA Button */}
        <div className="mb-16">
          <button
            onClick={scrollToContact}
            className="group inline-flex items-center gap-3 bg-[#00d4ff] hover:bg-[#00b8e6] text-black font-bold px-8 py-4 rounded-lg transition-all duration-300 transform hover:scale-105 hover:shadow-lg hover:shadow-[#00d4ff]/25"
            style={{ fontFamily: "Inter, sans-serif" }}
          >
            Let's Connect
            <ArrowRight 
              size={20} 
              className="group-hover:translate-x-1 transition-transform duration-300" 
            />
          </button>
        </div>

        {/* Tech stack indicators */}
        <div className="flex flex-wrap justify-center items-center gap-8 text-sm text-white/60">
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 bg-[#00d4ff] rounded-full"></div>
            <span style={{ fontFamily: "JetBrains Mono, monospace" }}>Full Stack</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 bg-[#00d4ff] rounded-full"></div>
            <span style={{ fontFamily: "JetBrains Mono, monospace" }}>Cloud Native</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 bg-[#00d4ff] rounded-full"></div>
            <span style={{ fontFamily: "JetBrains Mono, monospace" }}>AI Integration</span>
          </div>
        </div>
      </div>

      {/* Scroll indicator */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2">
        <div className="w-6 h-10 border-2 border-white/30 rounded-full flex justify-center">
          <div className="w-1 h-3 bg-[#00d4ff] rounded-full mt-2 animate-bounce"></div>
        </div>
      </div>
    </section>
  );
}