"use client";

import { useState } from "react";
import { ExternalLink, Github, ChevronLeft, ChevronRight } from "lucide-react";

export default function Projects() {
  const [activeFilter, setActiveFilter] = useState("All");

  const filters = ["All", "Web Apps", "Mobile Apps", "Full Stack", "API/Backend"];

  const projects = [
    {
      id: 1,
      title: "E-Commerce Platform",
      category: "Full Stack",
      description: "Complete e-commerce solution with payment integration, inventory management, and admin dashboard.",
      image: "https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?w=600&h=400&fit=crop",
      technologies: ["React", "Node.js", "MongoDB", "Stripe"],
      liveUrl: "#",
      githubUrl: "#",
      featured: true
    },
    {
      id: 2,
      title: "Task Management App",
      category: "Mobile Apps",
      description: "Cross-platform mobile app for team collaboration and project management.",
      image: "https://images.unsplash.com/photo-1611224923853-80b023f02d71?w=600&h=400&fit=crop",
      technologies: ["React Native", "Firebase", "Redux"],
      liveUrl: "#",
      githubUrl: "#",
      featured: false
    },
    {
      id: 3,
      title: "Analytics Dashboard",
      category: "Web Apps",
      description: "Real-time analytics dashboard with data visualization and reporting features.",
      image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=600&h=400&fit=crop",
      technologies: ["Vue.js", "D3.js", "Python", "PostgreSQL"],
      liveUrl: "#",
      githubUrl: "#",
      featured: true
    },
    {
      id: 4,
      title: "AI Chat API",
      category: "API/Backend",
      description: "RESTful API service with AI-powered chatbot integration and natural language processing.",
      image: "https://images.unsplash.com/photo-1677442136019-21780ecad995?w=600&h=400&fit=crop",
      technologies: ["Python", "FastAPI", "OpenAI", "Docker"],
      liveUrl: "#",
      githubUrl: "#",
      featured: false
    },
    {
      id: 5,
      title: "Social Media Platform",
      category: "Full Stack",
      description: "Social networking platform with real-time messaging, posts, and user interactions.",
      image: "https://images.unsplash.com/photo-1611162617474-5b21e879e113?w=600&h=400&fit=crop",
      technologies: ["Next.js", "Socket.io", "Redis", "AWS"],
      liveUrl: "#",
      githubUrl: "#",
      featured: true
    },
    {
      id: 6,
      title: "Fitness Tracker",
      category: "Mobile Apps",
      description: "Mobile fitness app with workout tracking, nutrition logging, and progress analytics.",
      image: "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=600&h=400&fit=crop",
      technologies: ["Flutter", "Firebase", "Charts"],
      liveUrl: "#",
      githubUrl: "#",
      featured: false
    }
  ];

  const filteredProjects = activeFilter === "All" 
    ? projects 
    : projects.filter(project => project.category === activeFilter);

  return (
    <section id="projects" className="bg-[#0f0f0f] py-20 px-6">
      <div className="max-w-7xl mx-auto">
        {/* Section Header */}
        <div className="text-center mb-16">
          <h2 
            className="text-4xl md:text-5xl font-bold text-white mb-4"
            style={{ fontFamily: "JetBrains Mono, monospace" }}
          >
            MY PROJECTS
          </h2>
          <div className="w-24 h-1 bg-[#00d4ff] mx-auto rounded-full mb-8"></div>
          <p 
            className="text-white/60 text-lg max-w-2xl mx-auto"
            style={{ fontFamily: "Inter, sans-serif" }}
          >
            A showcase of recent projects demonstrating my expertise in modern web and mobile development.
          </p>
        </div>

        {/* Filter Buttons */}
        <div className="flex flex-wrap justify-center gap-4 mb-12">
          {filters.map((filter) => (
            <button
              key={filter}
              onClick={() => setActiveFilter(filter)}
              className={`px-6 py-2 rounded-full font-medium transition-all duration-300 ${
                activeFilter === filter
                  ? "bg-[#00d4ff] text-black"
                  : "bg-[#1a1a1a] text-white/80 hover:text-white hover:bg-[#2a2a2a]"
              }`}
              style={{ fontFamily: "Inter, sans-serif" }}
            >
              {filter}
            </button>
          ))}
        </div>

        {/* Projects Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredProjects.map((project) => (
            <div 
              key={project.id}
              className="group bg-[#1a1a1a] rounded-lg overflow-hidden border border-[#2a2a2a] hover:border-[#00d4ff] transition-all duration-300 hover:transform hover:scale-105"
            >
              {/* Project Image */}
              <div className="relative overflow-hidden h-48">
                <img 
                  src={project.image} 
                  alt={project.title}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                />
                {project.featured && (
                  <div className="absolute top-4 right-4 bg-[#00d4ff] text-black px-2 py-1 rounded text-xs font-bold">
                    Featured
                  </div>
                )}
                <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center gap-4">
                  <a
                    href={project.liveUrl}
                    className="bg-[#00d4ff] text-black p-2 rounded-full hover:bg-white transition-colors"
                  >
                    <ExternalLink size={20} />
                  </a>
                  <a
                    href={project.githubUrl}
                    className="bg-[#00d4ff] text-black p-2 rounded-full hover:bg-white transition-colors"
                  >
                    <Github size={20} />
                  </a>
                </div>
              </div>

              {/* Project Info */}
              <div className="p-6">
                <div className="mb-2">
                  <span 
                    className="text-[#00d4ff] text-sm font-medium"
                    style={{ fontFamily: "JetBrains Mono, monospace" }}
                  >
                    {project.category}
                  </span>
                </div>
                
                <h3 
                  className="text-xl font-bold text-white mb-3"
                  style={{ fontFamily: "Inter, sans-serif" }}
                >
                  {project.title}
                </h3>
                
                <p 
                  className="text-white/70 text-sm mb-4 leading-relaxed"
                  style={{ fontFamily: "Inter, sans-serif" }}
                >
                  {project.description}
                </p>

                {/* Technologies */}
                <div className="flex flex-wrap gap-2">
                  {project.technologies.map((tech, index) => (
                    <span
                      key={index}
                      className="text-xs px-2 py-1 bg-[#00d4ff]/10 text-[#00d4ff] rounded border border-[#00d4ff]/20"
                      style={{ fontFamily: "JetBrains Mono, monospace" }}
                    >
                      {tech}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* View All Projects Button */}
        <div className="text-center mt-12">
          <button
            className="inline-flex items-center gap-2 bg-[#1a1a1a] hover:bg-[#2a2a2a] text-white border border-[#00d4ff] px-8 py-3 rounded-lg transition-all duration-300 font-medium"
            style={{ fontFamily: "Inter, sans-serif" }}
          >
            View All Projects
            <ExternalLink size={16} />
          </button>
        </div>
      </div>
    </section>
  );
}