"use client";

import { Heart, ArrowUp, Mail, Github, Linkedin, Twitter } from "lucide-react";

export default function Footer() {
  const currentYear = new Date().getFullYear();

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const quickLinks = [
    { label: "Home", href: "#home" },
    { label: "Services", href: "#services" },
    { label: "Projects", href: "#projects" },
    { label: "About", href: "#about" },
    { label: "Contact", href: "#contact" }
  ];

  const services = [
    "Web Development",
    "Mobile Apps", 
    "Cloud Solutions",
    "API Integration",
    "UI/UX Design"
  ];

  const socialLinks = [
    {
      icon: <Github size={20} />,
      href: "https://github.com/abdkafi",
      label: "GitHub"
    },
    {
      icon: <Linkedin size={20} />,
      href: "https://linkedin.com/in/abdkafi", 
      label: "LinkedIn"
    },
    {
      icon: <Twitter size={20} />,
      href: "https://twitter.com/abdkafi",
      label: "Twitter"
    },
    {
      icon: <Mail size={20} />,
      href: "mailto:abdullahil@kafi.dev",
      label: "Email"
    }
  ];

  return (
    <footer className="bg-[#0a0a0a] border-t border-[#1a1a1a] py-16 px-6 relative">
      <div className="max-w-7xl mx-auto">
        {/* Main Footer Content */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-12">
          {/* Brand Column */}
          <div className="lg:col-span-2">
            <div 
              className="text-2xl font-bold text-white mb-4"
              style={{ fontFamily: "JetBrains Mono, monospace" }}
            >
              ABDULLAHIL KAFI
            </div>
            <p 
              className="text-white/60 mb-6 leading-relaxed max-w-md"
              style={{ fontFamily: "Inter, sans-serif" }}
            >
              Full-stack developer passionate about creating innovative digital solutions. 
              Specializing in modern web technologies, mobile apps, and cloud infrastructure.
            </p>
            
            {/* Social Links */}
            <div className="flex gap-4">
              {socialLinks.map((social, index) => (
                <a
                  key={index}
                  href={social.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label={social.label}
                  className="p-3 bg-[#1a1a1a] border border-[#2a2a2a] rounded-lg text-white/70 hover:text-[#00d4ff] hover:border-[#00d4ff] transition-all duration-300 hover:scale-110"
                >
                  {social.icon}
                </a>
              ))}
            </div>
          </div>

          {/* Quick Links Column */}
          <div>
            <h3 
              className="text-lg font-bold text-white mb-6"
              style={{ fontFamily: "JetBrains Mono, monospace" }}
            >
              Quick Links
            </h3>
            <ul className="space-y-3">
              {quickLinks.map((link, index) => (
                <li key={index}>
                  <a
                    href={link.href}
                    className="text-white/60 hover:text-[#00d4ff] transition-colors duration-300 text-sm"
                    style={{ fontFamily: "Inter, sans-serif" }}
                    onClick={(e) => {
                      e.preventDefault();
                      const element = document.querySelector(link.href);
                      if (element) {
                        element.scrollIntoView({ behavior: 'smooth' });
                      }
                    }}
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Services Column */}
          <div>
            <h3 
              className="text-lg font-bold text-white mb-6"
              style={{ fontFamily: "JetBrains Mono, monospace" }}
            >
              Services
            </h3>
            <ul className="space-y-3">
              {services.map((service, index) => (
                <li 
                  key={index}
                  className="text-white/60 text-sm"
                  style={{ fontFamily: "Inter, sans-serif" }}
                >
                  {service}
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Bottom Footer */}
        <div className="pt-8 border-t border-[#1a1a1a]">
          <div className="flex flex-col md:flex-row justify-between items-center gap-6">
            {/* Copyright */}
            <div className="flex items-center gap-2 text-white/50 text-sm">
              <span style={{ fontFamily: "Inter, sans-serif" }}>
                © {currentYear} Abdullahil Kafi. Made with
              </span>
              <Heart size={16} className="text-red-500" />
              <span style={{ fontFamily: "Inter, sans-serif" }}>
                in Bangladesh
              </span>
            </div>

            {/* Back to Top Button */}
            <button
              onClick={scrollToTop}
              className="flex items-center gap-2 text-white/60 hover:text-[#00d4ff] transition-colors duration-300 text-sm group"
              style={{ fontFamily: "Inter, sans-serif" }}
            >
              Back to top
              <ArrowUp size={16} className="group-hover:-translate-y-1 transition-transform duration-300" />
            </button>
          </div>

          {/* Additional Links */}
          <div className="mt-6 pt-6 border-t border-[#1a1a1a]/50 text-center">
            <div className="flex flex-wrap justify-center gap-6 text-xs text-white/40">
              <a href="#" className="hover:text-[#00d4ff] transition-colors">Privacy Policy</a>
              <a href="#" className="hover:text-[#00d4ff] transition-colors">Terms of Service</a>
              <a href="#" className="hover:text-[#00d4ff] transition-colors">Sitemap</a>
            </div>
          </div>
        </div>
      </div>

      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-5 pointer-events-none">
        <div 
          className="w-full h-full"
          style={{
            backgroundImage: `
              linear-gradient(rgba(0, 212, 255, 0.1) 1px, transparent 1px),
              linear-gradient(90deg, rgba(0, 212, 255, 0.1) 1px, transparent 1px)
            `,
            backgroundSize: '50px 50px'
          }}
        ></div>
      </div>
    </footer>
  );
}