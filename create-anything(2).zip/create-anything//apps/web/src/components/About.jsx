"use client";

import { Download, MapPin, Calendar, Award } from "lucide-react";

export default function About() {
  const stats = [
    { number: "5+", label: "Years Experience" },
    { number: "50+", label: "Projects Completed" },
    { number: "30+", label: "Happy Clients" },
    { number: "15+", label: "Technologies" }
  ];

  return (
    <section id="about" className="bg-[#0a0a0a] py-20 px-6">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          {/* Left Column - Image and Stats */}
          <div className="relative">
            {/* Profile Image */}
            <div className="relative mb-8">
              <div className="w-80 h-80 mx-auto lg:mx-0 rounded-lg overflow-hidden border border-[#2a2a2a]">
                <img 
                  src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=400&h=400&fit=crop&crop=face"
                  alt="Abdullahil Kafi - Full Stack Developer"
                  className="w-full h-full object-cover"
                />
              </div>
              {/* Floating badge */}
              <div className="absolute -bottom-4 -right-4 bg-[#00d4ff] text-black px-4 py-2 rounded-lg font-bold">
                <div className="text-center">
                  <div className="text-sm">Available for</div>
                  <div className="text-xs">Freelance</div>
                </div>
              </div>
            </div>

            {/* Stats Grid */}
            <div className="grid grid-cols-2 gap-4">
              {stats.map((stat, index) => (
                <div 
                  key={index}
                  className="bg-[#1a1a1a] border border-[#2a2a2a] rounded-lg p-4 text-center"
                >
                  <div 
                    className="text-2xl font-bold text-[#00d4ff] mb-1"
                    style={{ fontFamily: "JetBrains Mono, monospace" }}
                  >
                    {stat.number}
                  </div>
                  <div 
                    className="text-sm text-white/70"
                    style={{ fontFamily: "Inter, sans-serif" }}
                  >
                    {stat.label}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Right Column - About Content */}
          <div>
            <h2 
              className="text-4xl md:text-5xl font-bold text-white mb-6"
              style={{ fontFamily: "JetBrains Mono, monospace" }}
            >
              ABOUT ME
            </h2>
            <div className="w-24 h-1 bg-[#00d4ff] rounded-full mb-8"></div>

            <div className="space-y-6 mb-8">
              <p 
                className="text-white/80 text-lg leading-relaxed"
                style={{ fontFamily: "Inter, sans-serif" }}
              >
                I'm a passionate full-stack developer with over 5 years of experience crafting 
                digital solutions that make a difference. I specialize in modern web technologies, 
                cloud architecture, and mobile app development.
              </p>
              
              <p 
                className="text-white/70 leading-relaxed"
                style={{ fontFamily: "Inter, sans-serif" }}
              >
                My journey in technology started with a curiosity about how things work behind 
                the scenes. Today, I help businesses and startups bring their ideas to life 
                through clean code, scalable architectures, and user-centered design.
              </p>
            </div>

            {/* Quick Info */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
              <div className="flex items-center gap-3">
                <MapPin size={20} className="text-[#00d4ff]" />
                <span className="text-white/80" style={{ fontFamily: "Inter, sans-serif" }}>
                  Dhaka, Bangladesh
                </span>
              </div>
              <div className="flex items-center gap-3">
                <Calendar size={20} className="text-[#00d4ff]" />
                <span className="text-white/80" style={{ fontFamily: "Inter, sans-serif" }}>
                  Available Now
                </span>
              </div>
              <div className="flex items-center gap-3">
                <Award size={20} className="text-[#00d4ff]" />
                <span className="text-white/80" style={{ fontFamily: "Inter, sans-serif" }}>
                  Certified Developer
                </span>
              </div>
            </div>

            {/* Download Resume Button */}
            <button
              className="inline-flex items-center gap-3 bg-[#00d4ff] hover:bg-[#00b8e6] text-black font-bold px-6 py-3 rounded-lg transition-all duration-300 hover:shadow-lg hover:shadow-[#00d4ff]/25"
              style={{ fontFamily: "Inter, sans-serif" }}
            >
              <Download size={20} />
              Download Resume
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}