"use client";

export default function Skills() {
  const skillCategories = [
    {
      title: "Frontend",
      skills: [
        { name: "React", level: 95 },
        { name: "Next.js", level: 90 },
        { name: "TypeScript", level: 85 },
        { name: "Vue.js", level: 80 },
        { name: "Tailwind CSS", level: 90 }
      ]
    },
    {
      title: "Backend", 
      skills: [
        { name: "Node.js", level: 90 },
        { name: "Python", level: 85 },
        { name: "PostgreSQL", level: 80 },
        { name: "MongoDB", level: 85 },
        { name: "GraphQL", level: 75 }
      ]
    },
    {
      title: "Mobile",
      skills: [
        { name: "React Native", level: 85 },
        { name: "Flutter", level: 80 },
        { name: "Expo", level: 90 },
        { name: "iOS", level: 70 },
        { name: "Android", level: 75 }
      ]
    },
    {
      title: "DevOps & Cloud",
      skills: [
        { name: "AWS", level: 80 },
        { name: "Docker", level: 85 },
        { name: "Kubernetes", level: 70 },
        { name: "CI/CD", level: 80 },
        { name: "Nginx", level: 75 }
      ]
    }
  ];

  const tools = [
    "VS Code", "Git", "GitHub", "Figma", "Postman", 
    "Jira", "Slack", "Firebase", "Vercel", "Railway",
    "Supabase", "Prisma", "Redux", "Zustand", "Jest"
  ];

  return (
    <section className="bg-[#0f0f0f] py-20 px-6">
      <div className="max-w-7xl mx-auto">
        {/* Section Header */}
        <div className="text-center mb-16">
          <h2 
            className="text-4xl md:text-5xl font-bold text-white mb-4"
            style={{ fontFamily: "JetBrains Mono, monospace" }}
          >
            MY SKILLS
          </h2>
          <div className="w-24 h-1 bg-[#00d4ff] mx-auto rounded-full mb-8"></div>
          <p 
            className="text-white/60 text-lg max-w-2xl mx-auto"
            style={{ fontFamily: "Inter, sans-serif" }}
          >
            Technical expertise across the full stack, from frontend frameworks to cloud infrastructure.
          </p>
        </div>

        {/* Skills Categories */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-16">
          {skillCategories.map((category, categoryIndex) => (
            <div 
              key={categoryIndex}
              className="bg-[#1a1a1a] border border-[#2a2a2a] rounded-lg p-6"
            >
              <h3 
                className="text-xl font-bold text-white mb-6 text-center"
                style={{ fontFamily: "JetBrains Mono, monospace" }}
              >
                {category.title}
              </h3>
              
              <div className="space-y-4">
                {category.skills.map((skill, skillIndex) => (
                  <div key={skillIndex}>
                    <div className="flex justify-between items-center mb-2">
                      <span 
                        className="text-white/80 text-sm"
                        style={{ fontFamily: "Inter, sans-serif" }}
                      >
                        {skill.name}
                      </span>
                      <span 
                        className="text-[#00d4ff] text-xs font-mono"
                        style={{ fontFamily: "JetBrains Mono, monospace" }}
                      >
                        {skill.level}%
                      </span>
                    </div>
                    <div className="w-full bg-[#2a2a2a] rounded-full h-2">
                      <div 
                        className="bg-[#00d4ff] h-2 rounded-full transition-all duration-1000 ease-out"
                        style={{ width: `${skill.level}%` }}
                      ></div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>

        {/* Tools & Technologies */}
        <div className="bg-[#1a1a1a] border border-[#2a2a2a] rounded-lg p-8">
          <h3 
            className="text-2xl font-bold text-white mb-6 text-center"
            style={{ fontFamily: "JetBrains Mono, monospace" }}
          >
            Tools & Technologies
          </h3>
          
          <div className="flex flex-wrap justify-center gap-3">
            {tools.map((tool, index) => (
              <span
                key={index}
                className="px-4 py-2 bg-[#0a0a0a] border border-[#00d4ff]/20 text-[#00d4ff] rounded-lg hover:bg-[#00d4ff]/10 transition-colors duration-300"
                style={{ fontFamily: "JetBrains Mono, monospace" }}
              >
                {tool}
              </span>
            ))}
          </div>
        </div>

        {/* Certifications */}
        <div className="mt-16 text-center">
          <h3 
            className="text-2xl font-bold text-white mb-8"
            style={{ fontFamily: "JetBrains Mono, monospace" }}
          >
            Certifications
          </h3>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[
              { title: "AWS Solutions Architect", issuer: "Amazon Web Services", year: "2023" },
              { title: "React Developer", issuer: "Meta", year: "2022" },
              { title: "Full Stack Developer", issuer: "freeCodeCamp", year: "2021" }
            ].map((cert, index) => (
              <div 
                key={index}
                className="bg-[#1a1a1a] border border-[#2a2a2a] rounded-lg p-4 hover:border-[#00d4ff] transition-colors duration-300"
              >
                <h4 
                  className="font-bold text-white mb-2"
                  style={{ fontFamily: "Inter, sans-serif" }}
                >
                  {cert.title}
                </h4>
                <p 
                  className="text-[#00d4ff] text-sm mb-1"
                  style={{ fontFamily: "Inter, sans-serif" }}
                >
                  {cert.issuer}
                </p>
                <p 
                  className="text-white/60 text-sm"
                  style={{ fontFamily: "JetBrains Mono, monospace" }}
                >
                  {cert.year}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}