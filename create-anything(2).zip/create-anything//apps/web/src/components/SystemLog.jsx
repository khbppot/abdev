"use client";

import { useState, useEffect } from "react";
import { Terminal, Play, Square } from "lucide-react";

export default function SystemLog() {
  const [currentCommand, setCurrentCommand] = useState(0);
  const [isRunning, setIsRunning] = useState(true);

  const logEntries = [
    { time: "09:15:42", type: "INFO", message: "System initialized successfully" },
    { time: "09:15:43", type: "INFO", message: "Loading project modules..." },
    { time: "09:15:44", type: "SUCCESS", message: "✓ React application started" },
    { time: "09:15:45", type: "SUCCESS", message: "✓ Database connection established" },
    { time: "09:15:46", type: "INFO", message: "Compiling TypeScript files..." },
    { time: "09:15:47", type: "SUCCESS", message: "✓ Build completed successfully" },
    { time: "09:15:48", type: "INFO", message: "Deploying to production..." },
    { time: "09:15:49", type: "SUCCESS", message: "✓ Deployment successful" },
    { time: "09:15:50", type: "INFO", message: "Application running on https://abdkafi.dev" },
    { time: "09:15:51", type: "SUCCESS", message: "✓ All systems operational" }
  ];

  const commands = [
    "npm run build",
    "docker compose up -d",
    "git push origin main",
    "kubectl apply -f deployment.yaml",
    "npm test",
    "yarn deploy"
  ];

  useEffect(() => {
    if (isRunning) {
      const interval = setInterval(() => {
        setCurrentCommand(prev => (prev + 1) % commands.length);
      }, 2000);
      return () => clearInterval(interval);
    }
  }, [isRunning, commands.length]);

  const getLogColor = (type) => {
    switch (type) {
      case "SUCCESS": return "text-green-400";
      case "INFO": return "text-blue-400";
      case "WARNING": return "text-yellow-400";
      case "ERROR": return "text-red-400";
      default: return "text-white/70";
    }
  };

  return (
    <section className="bg-[#0a0a0a] py-20 px-6">
      <div className="max-w-7xl mx-auto">
        {/* Section Header */}
        <div className="text-center mb-16">
          <h2 
            className="text-4xl md:text-5xl font-bold text-white mb-4"
            style={{ fontFamily: "JetBrains Mono, monospace" }}
          >
            SYSTEM LOG
          </h2>
          <div className="w-24 h-1 bg-[#00d4ff] mx-auto rounded-full mb-8"></div>
          <p 
            className="text-white/60 text-lg max-w-2xl mx-auto"
            style={{ fontFamily: "Inter, sans-serif" }}
          >
            Real-time development environment showing current system status and build processes.
          </p>
        </div>

        {/* Terminal Window */}
        <div className="max-w-5xl mx-auto">
          <div className="bg-[#1a1a1a] rounded-lg border border-[#2a2a2a] overflow-hidden">
            {/* Terminal Header */}
            <div className="bg-[#0f0f0f] px-6 py-3 border-b border-[#2a2a2a] flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 bg-red-500 rounded-full"></div>
                  <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>
                  <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                </div>
                <div className="flex items-center gap-2">
                  <Terminal size={16} className="text-[#00d4ff]" />
                  <span 
                    className="text-white/80 text-sm"
                    style={{ fontFamily: "JetBrains Mono, monospace" }}
                  >
                    abdkafi@dev-server:~$
                  </span>
                </div>
              </div>
              
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setIsRunning(!isRunning)}
                  className="flex items-center gap-1 px-3 py-1 bg-[#2a2a2a] hover:bg-[#3a3a3a] text-white/80 text-xs rounded border border-[#00d4ff]/20 transition-colors"
                  style={{ fontFamily: "JetBrains Mono, monospace" }}
                >
                  {isRunning ? <Square size={12} /> : <Play size={12} />}
                  {isRunning ? "Stop" : "Start"}
                </button>
              </div>
            </div>

            {/* Terminal Content */}
            <div className="p-6 h-96 overflow-y-auto">
              {/* Current Command */}
              <div className="mb-4">
                <div className="flex items-center gap-2 mb-2">
                  <span 
                    className="text-[#00d4ff]"
                    style={{ fontFamily: "JetBrains Mono, monospace" }}
                  >
                    abdkafi@dev-server:~$
                  </span>
                  <span 
                    className="text-white"
                    style={{ fontFamily: "JetBrains Mono, monospace" }}
                  >
                    {commands[currentCommand]}
                  </span>
                  <span className="w-2 h-4 bg-[#00d4ff] animate-pulse ml-1"></span>
                </div>
              </div>

              {/* Log Entries */}
              <div className="space-y-1">
                {logEntries.map((entry, index) => (
                  <div 
                    key={index}
                    className="flex items-start gap-4 text-sm"
                    style={{ fontFamily: "JetBrains Mono, monospace" }}
                  >
                    <span className="text-white/50 min-w-[60px]">
                      {entry.time}
                    </span>
                    <span className={`min-w-[60px] ${getLogColor(entry.type)}`}>
                      [{entry.type}]
                    </span>
                    <span className="text-white/80 flex-1">
                      {entry.message}
                    </span>
                  </div>
                ))}
              </div>

              {/* System Status */}
              <div className="mt-6 pt-4 border-t border-[#2a2a2a]">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                  <div className="flex justify-between">
                    <span className="text-white/60" style={{ fontFamily: "JetBrains Mono, monospace" }}>
                      CPU Usage:
                    </span>
                    <span className="text-green-400" style={{ fontFamily: "JetBrains Mono, monospace" }}>
                      23%
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-white/60" style={{ fontFamily: "JetBrains Mono, monospace" }}>
                      Memory:
                    </span>
                    <span className="text-blue-400" style={{ fontFamily: "JetBrains Mono, monospace" }}>
                      1.2GB
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-white/60" style={{ fontFamily: "JetBrains Mono, monospace" }}>
                      Uptime:
                    </span>
                    <span className="text-[#00d4ff]" style={{ fontFamily: "JetBrains Mono, monospace" }}>
                      99.9%
                    </span>
                  </div>
                </div>
              </div>

              {/* Performance Metrics */}
              <div className="mt-4">
                <div className="text-sm text-white/60 mb-2" style={{ fontFamily: "JetBrains Mono, monospace" }}>
                  Recent Deployments:
                </div>
                <div className="space-y-1 text-xs">
                  <div className="flex justify-between" style={{ fontFamily: "JetBrains Mono, monospace" }}>
                    <span className="text-white/60">v2.4.1 - Production</span>
                    <span className="text-green-400">✓ Success</span>
                  </div>
                  <div className="flex justify-between" style={{ fontFamily: "JetBrains Mono, monospace" }}>
                    <span className="text-white/60">v2.4.0 - Staging</span>
                    <span className="text-green-400">✓ Success</span>
                  </div>
                  <div className="flex justify-between" style={{ fontFamily: "JetBrains Mono, monospace" }}>
                    <span className="text-white/60">v2.3.9 - Development</span>
                    <span className="text-green-400">✓ Success</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}