"use client";

import { useState } from "react";
import { Mail, Phone, MapPin, Send, Github, Linkedin, Twitter, MessageCircle } from "lucide-react";

export default function Contact() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    subject: "",
    message: ""
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // Simulate form submission
    setTimeout(() => {
      alert("Message sent successfully! I'll get back to you soon.");
      setFormData({ name: "", email: "", subject: "", message: "" });
      setIsSubmitting(false);
    }, 2000);
  };

  const contactInfo = [
    {
      icon: <Mail size={24} />,
      title: "Email",
      value: "abdullahil@kafi.dev",
      href: "mailto:abdullahil@kafi.dev"
    },
    {
      icon: <Phone size={24} />,
      title: "Phone",
      value: "+880 1234 567890",
      href: "tel:+8801234567890"
    },
    {
      icon: <MapPin size={24} />,
      title: "Location",
      value: "Dhaka, Bangladesh",
      href: "#"
    }
  ];

  const socialLinks = [
    {
      icon: <Github size={20} />,
      name: "GitHub",
      href: "https://github.com/abdkafi",
      color: "hover:text-white"
    },
    {
      icon: <Linkedin size={20} />,
      name: "LinkedIn", 
      href: "https://linkedin.com/in/abdkafi",
      color: "hover:text-blue-400"
    },
    {
      icon: <Twitter size={20} />,
      name: "Twitter",
      href: "https://twitter.com/abdkafi",
      color: "hover:text-blue-400"
    },
    {
      icon: <MessageCircle size={20} />,
      name: "WhatsApp",
      href: "https://wa.me/8801234567890",
      color: "hover:text-green-400"
    }
  ];

  return (
    <section id="contact" className="bg-[#0f0f0f] py-20 px-6">
      <div className="max-w-7xl mx-auto">
        {/* Section Header */}
        <div className="text-center mb-16">
          <h2 
            className="text-4xl md:text-5xl font-bold text-white mb-4"
            style={{ fontFamily: "JetBrains Mono, monospace" }}
          >
            GET IN TOUCH
          </h2>
          <div className="w-24 h-1 bg-[#00d4ff] mx-auto rounded-full mb-8"></div>
          <p 
            className="text-white/60 text-lg max-w-2xl mx-auto"
            style={{ fontFamily: "Inter, sans-serif" }}
          >
            Ready to start your next project? Let's discuss how I can help bring your ideas to life.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
          {/* Contact Information */}
          <div>
            <h3 
              className="text-2xl font-bold text-white mb-8"
              style={{ fontFamily: "JetBrains Mono, monospace" }}
            >
              Contact Information
            </h3>

            <div className="space-y-6 mb-8">
              {contactInfo.map((info, index) => (
                <a
                  key={index}
                  href={info.href}
                  className="flex items-center gap-4 p-4 bg-[#1a1a1a] border border-[#2a2a2a] rounded-lg hover:border-[#00d4ff] transition-all duration-300 group"
                >
                  <div className="text-[#00d4ff] group-hover:scale-110 transition-transform">
                    {info.icon}
                  </div>
                  <div>
                    <h4 
                      className="font-semibold text-white mb-1"
                      style={{ fontFamily: "Inter, sans-serif" }}
                    >
                      {info.title}
                    </h4>
                    <p 
                      className="text-white/70 text-sm"
                      style={{ fontFamily: "JetBrains Mono, monospace" }}
                    >
                      {info.value}
                    </p>
                  </div>
                </a>
              ))}
            </div>

            {/* Social Links */}
            <div>
              <h4 
                className="text-lg font-bold text-white mb-4"
                style={{ fontFamily: "JetBrains Mono, monospace" }}
              >
                Follow Me
              </h4>
              <div className="flex gap-4">
                {socialLinks.map((social, index) => (
                  <a
                    key={index}
                    href={social.href}
                    target="_blank"
                    rel="noopener noreferrer"
                    className={`p-3 bg-[#1a1a1a] border border-[#2a2a2a] rounded-lg text-white/70 ${social.color} transition-all duration-300 hover:border-[#00d4ff] hover:scale-110`}
                    aria-label={social.name}
                  >
                    {social.icon}
                  </a>
                ))}
              </div>
            </div>
          </div>

          {/* Contact Form */}
          <div>
            <h3 
              className="text-2xl font-bold text-white mb-8"
              style={{ fontFamily: "JetBrains Mono, monospace" }}
            >
              Send Message
            </h3>

            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label 
                    htmlFor="name"
                    className="block text-sm font-medium text-white/80 mb-2"
                    style={{ fontFamily: "Inter, sans-serif" }}
                  >
                    Your Name
                  </label>
                  <input
                    type="text"
                    id="name"
                    name="name"
                    value={formData.name}
                    onChange={handleInputChange}
                    required
                    className="w-full px-4 py-3 bg-[#1a1a1a] border border-[#2a2a2a] rounded-lg text-white placeholder-white/40 focus:outline-none focus:border-[#00d4ff] transition-colors"
                    style={{ fontFamily: "Inter, sans-serif" }}
                    placeholder="John Doe"
                  />
                </div>

                <div>
                  <label 
                    htmlFor="email"
                    className="block text-sm font-medium text-white/80 mb-2"
                    style={{ fontFamily: "Inter, sans-serif" }}
                  >
                    Email Address
                  </label>
                  <input
                    type="email"
                    id="email"
                    name="email"
                    value={formData.email}
                    onChange={handleInputChange}
                    required
                    className="w-full px-4 py-3 bg-[#1a1a1a] border border-[#2a2a2a] rounded-lg text-white placeholder-white/40 focus:outline-none focus:border-[#00d4ff] transition-colors"
                    style={{ fontFamily: "Inter, sans-serif" }}
                    placeholder="john@example.com"
                  />
                </div>
              </div>

              <div>
                <label 
                  htmlFor="subject"
                  className="block text-sm font-medium text-white/80 mb-2"
                  style={{ fontFamily: "Inter, sans-serif" }}
                >
                  Subject
                </label>
                <input
                  type="text"
                  id="subject"
                  name="subject"
                  value={formData.subject}
                  onChange={handleInputChange}
                  required
                  className="w-full px-4 py-3 bg-[#1a1a1a] border border-[#2a2a2a] rounded-lg text-white placeholder-white/40 focus:outline-none focus:border-[#00d4ff] transition-colors"
                  style={{ fontFamily: "Inter, sans-serif" }}
                  placeholder="Project Discussion"
                />
              </div>

              <div>
                <label 
                  htmlFor="message"
                  className="block text-sm font-medium text-white/80 mb-2"
                  style={{ fontFamily: "Inter, sans-serif" }}
                >
                  Message
                </label>
                <textarea
                  id="message"
                  name="message"
                  value={formData.message}
                  onChange={handleInputChange}
                  required
                  rows={6}
                  className="w-full px-4 py-3 bg-[#1a1a1a] border border-[#2a2a2a] rounded-lg text-white placeholder-white/40 focus:outline-none focus:border-[#00d4ff] transition-colors resize-none"
                  style={{ fontFamily: "Inter, sans-serif" }}
                  placeholder="Tell me about your project or how I can help you..."
                />
              </div>

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full flex items-center justify-center gap-3 bg-[#00d4ff] hover:bg-[#00b8e6] disabled:bg-[#00d4ff]/50 text-black font-bold px-8 py-4 rounded-lg transition-all duration-300 hover:shadow-lg hover:shadow-[#00d4ff]/25 disabled:cursor-not-allowed"
                style={{ fontFamily: "Inter, sans-serif" }}
              >
                {isSubmitting ? (
                  <>
                    <div className="w-5 h-5 border-2 border-black/30 border-t-black rounded-full animate-spin"></div>
                    Sending...
                  </>
                ) : (
                  <>
                    <Send size={20} />
                    Send Message
                  </>
                )}
              </button>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
}