"use client";

import { Code, Smartphone, Cloud, Settings } from "lucide-react";

export default function Services() {
  const services = [
    {
      icon: <Code size={32} />,
      title: "Web Development",
      description: "Full-stack web applications with modern frameworks and responsive design.",
      technologies: ["React", "Next.js", "Node.js", "TypeScript"]
    },
    {
      icon: <Smartphone size={32} />,
      title: "Mobile Apps",
      description: "Cross-platform mobile applications with native performance and user experience.",
      technologies: ["React Native", "Flutter", "Expo", "iOS/Android"]
    },
    {
      icon: <Cloud size={32} />,
      title: "Cloud Solutions",
      description: "Scalable cloud infrastructure and serverless applications for modern businesses.",
      technologies: ["AWS", "Azure", "Docker", "Kubernetes"]
    },
    {
      icon: <Settings size={32} />,
      title: "API Integration",
      description: "RESTful APIs, GraphQL services, and third-party integrations.",
      technologies: ["REST API", "GraphQL", "Microservices", "OAuth"]
    }
  ];

  return (
    <section id="services" className="bg-[#0a0a0a] py-20 px-6">
      <div className="max-w-7xl mx-auto">
        {/* Section Header */}
        <div className="text-center mb-16">
          <h2 
            className="text-4xl md:text-5xl font-bold text-white mb-4"
            style={{ fontFamily: "JetBrains Mono, monospace" }}
          >
            MY SERVICES
          </h2>
          <div className="w-24 h-1 bg-[#00d4ff] mx-auto rounded-full"></div>
        </div>

        {/* Services Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {services.map((service, index) => (
            <div 
              key={index}
              className="group bg-[#1a1a1a] border border-[#2a2a2a] rounded-lg p-6 hover:border-[#00d4ff] transition-all duration-300 hover:transform hover:scale-105 hover:shadow-lg hover:shadow-[#00d4ff]/10"
            >
              {/* Icon */}
              <div className="text-[#00d4ff] mb-4 group-hover:scale-110 transition-transform duration-300">
                {service.icon}
              </div>

              {/* Title */}
              <h3 
                className="text-xl font-bold text-white mb-3"
                style={{ fontFamily: "Inter, sans-serif" }}
              >
                {service.title}
              </h3>

              {/* Description */}
              <p 
                className="text-white/70 text-sm mb-4 leading-relaxed"
                style={{ fontFamily: "Inter, sans-serif" }}
              >
                {service.description}
              </p>

              {/* Technologies */}
              <div className="flex flex-wrap gap-2">
                {service.technologies.map((tech, techIndex) => (
                  <span
                    key={techIndex}
                    className="text-xs px-2 py-1 bg-[#00d4ff]/10 text-[#00d4ff] rounded border border-[#00d4ff]/20"
                    style={{ fontFamily: "JetBrains Mono, monospace" }}
                  >
                    {tech}
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>

        {/* Additional Info */}
        <div className="text-center mt-16">
          <p 
            className="text-white/60 text-lg max-w-2xl mx-auto"
            style={{ fontFamily: "Inter, sans-serif" }}
          >
            Delivering high-quality solutions with cutting-edge technologies 
            to help businesses grow and succeed in the digital world.
          </p>
        </div>
      </div>
    </section>
  );
}