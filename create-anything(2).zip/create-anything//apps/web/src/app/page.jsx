import Header from "../components/Header";
import Hero from "../components/Hero";
import Services from "../components/Services";
import Projects from "../components/Projects";
import About from "../components/About";
import Skills from "../components/Skills";
import SystemLog from "../components/SystemLog";
import Contact from "../components/Contact";
import Footer from "../components/Footer";

export default function HomePage() {
  return (
    <div className="min-h-screen bg-[#0a0a0a] text-white">
      {/* Header - Navigation with dark theme */}
      <Header />

      {/* Hero Section - "Crafting the Future of Tech" */}
      <Hero />

      {/* Services Section - "MY SERVICE" with tech service cards */}
      <Services />

      {/* Projects Section - New section with project showcases */}
      <Projects />

      {/* About Section - Personal information */}
      <About />

      {/* Skills Section - Technical skills */}
      <Skills />

      {/* System Log Section - Terminal-style display */}
      <SystemLog />

      {/* Contact Section - Get in touch */}
      <Contact />

      {/* Footer */}
      <Footer />
    </div>
  );
}